-- PED GARAGE

local ped = nil

Citizen.CreateThread(function()
    local pedModel = GetHashKey("s_m_m_ccrew_01") -- Site pour les peds : https://docs.fivem.net/docs/game-references/ped-models/

    RequestModel(pedModel)
    while not HasModelLoaded(pedModel) do
        Wait(1)
    end

    ped = CreatePed(4, pedModel, -1392.22, -638.48, 28.69, 305, false, true) -- Position du ped
    SetEntityHeading(ped, 305)
    TaskStartScenarioInPlace(ped, "WORLD_HUMAN_CLIPBOARD", 0, true) -- Animation
    SetEntityInvincible(ped, true)
    SetPedCombatAttributes(ped, 46, true)
    SetPedCombatAbility(ped, 0)
    SetPedCanSwitchWeapon(ped, false)
    SetBlockingOfNonTemporaryEvents(ped, true)

    Wait(1500) -- (Pour éviter les bugs)

    FreezeEntityPosition(ped, true)
end)