fx_version 'adamant'
game 'gta5'

lua54 'yes'

shared_scripts {
	'@ox_lib/init.lua',
	'@es_extended/imports.lua'
}

client_scripts {
	'config.lua',
	'client/cl_bahamas.lua',
	'client/cl_vehiclebahamas.lua',
	'client/cl_jobmenu.lua',
	'client/cl_peds.lua'
}

server_scripts {
	'config.lua',
	'server/sv_bahamas.lua',
	'@oxmysql/lib/MySQL.lua'
}

dependencies {
	'es_extended',
	'epic_bahamasjob',
	'okokChat', -- Vous pouvez tenter d\'enlever cette ligne pour faire fonctionner de force le job sauf que les annonces ne fonctionneront pas !
	'/assetpacks'
}