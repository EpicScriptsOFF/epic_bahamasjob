
INSERT INTO `addon_account` (name, label, shared) VALUES
	('society_bahamas', 'bahamas', 1)
;

INSERT INTO `datastore` (name, label, shared) VALUES
	('society_bahamas', 'bahamas', 1)
;

INSERT INTO `addon_inventory` (name, label, shared) VALUES
	('society_bahamas', 'bahamas', 1)
;

INSERT INTO `jobs` (name, label) VALUES
	('bahamas', 'bahamas')
;

INSERT INTO `job_grades` (job_name, grade, name, label, salary, skin_male, skin_female) VALUES
	('bahamas',1,'recrue','Recrue',12,'{}','{}'),
    ('bahamas',2,'experimenter','Barman',12,'{}','{}'),
	('bahamas',3,'coboss','Co-Patron',12,'{}','{}'),
	('bahamas',4,'boss','Patron',12,'{}','{}')
;

-- FIN SQL


-- Si vous avez des erreurs au niveau de l'sql, tester cela :


INSERT INTO `addon_account` (name, label, shared) VALUES
	('society_bahamas', 'bahamas', 1)
;

INSERT INTO `datastore` (name, label, shared) VALUES
	('society_bahamas', 'bahamas', 1)
;

INSERT INTO `addon_inventory` (name, label, shared) VALUES
	('society_bahamas', 'bahamas', 1)
;

INSERT INTO `jobs` (name, label) VALUES
	('bahamas', 'bahamas')
;

INSERT INTO `job_grades` (id, job_name, grade, name, label, salary, skin_male, skin_female) VALUES
	(95, 'bahamas',1,'recrue','Recrue',12,'{}','{}'),
    (96, 'bahamas',2,'experimenter','Barman',12,'{}','{}'),
	(97, 'bahamas',3,'coboss','Co-Patron',12,'{}','{}'),
	(98, 'bahamas',4,'boss','Patron',12,'{}','{}')
;
